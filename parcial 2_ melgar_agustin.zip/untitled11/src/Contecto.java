public class Contecto extends Persona {
    public Contecto(String nombre, String apellido, int DNI, String telefono, String email) {
        super(nombre, apellido, DNI, telefono, email);
    }


    public void modificarDatos(String nombre, String apellido,  String telefono, String email,int DNI) {
        super.setNombre(nombre);
        super.setApellido(apellido);
        super.setEmail(email);
        super.setTelefono(telefono);
        try{
            super.setDNI(Integer.parseInt(String.valueOf(DNI)));
        }catch (Exception e){
            System.out.println("ERROR: Eso no parece ser un número de legajo.");
        }

    }

    @Override
    public String toString() {
        return super.toString();
    }
}
