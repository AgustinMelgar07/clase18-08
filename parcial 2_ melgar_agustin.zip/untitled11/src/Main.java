import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        int opcion;
        Scanner n=new Scanner(System.in);
        AdministarContactos contaco= new AdministarContactos();
        do {
            System.out.println("1_nuevo Contecto\n"
                    + "2_Lista todos los contectos\n"
                    + "3_Busca Contactos por nombre o apellido\n"
                    + "4_Busca Contacto po DNI\n"
                    + "5_eliminar Contacto por DNI\n"
                    + "6_imprimi en un archivo\n(no esta)"
                    + "7_edita Contacto\n"
                    + "99_salir");
            System.out.println("ingrese una opcion");
            opcion=n.nextInt();
            switch (opcion) {
                case 1:
                        contaco.agregarContactos();

                    break;
                case 2:
                    contaco.listarContactos();
                    break;
                case 3:
                    contaco.BuscarPorNombreYApellido();
                    break;
                case 4:
                    contaco.BuscarPorDNI();
                    break;
                case 5:contaco.EliminarPorDNI();
                    break;
                case 6:
                    break;
                case 7:contaco.ModificaPorDNI();
                    break;
                case 99:
                    break;
                default:
                    System.out.println("OPCION INCORRECTA");


            }
        }while (opcion!=99);
    }
}
