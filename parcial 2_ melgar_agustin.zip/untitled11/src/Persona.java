public class Persona {
    private String nombre;
    private String  apellido;
    private int DNI;
    private String telefono;
    private String email;

    public Persona(  String nombre, String  apellido, int DNI, String telefono, String email){
        this.setNombre(nombre);
        this.setApellido(apellido);
        this.setDNI(DNI);
        this.setTelefono(telefono);
        this.setEmail(email);
    }


    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getDNI() {
        return DNI;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "[NOMBRE: "+getNombre()
                +", APELLIDO: "+getApellido()
                +", TELEFONO: "+getTelefono()
                +", EMAIL: "+getEmail()
                +", DNI: "+getDNI();
    }
}
