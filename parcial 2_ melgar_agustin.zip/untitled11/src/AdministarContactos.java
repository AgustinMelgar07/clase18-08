import java.io.*;
import java.util.LinkedList;
import java.util.Scanner;

public class AdministarContactos {
    LinkedList <Contecto> contactos;

    String nombre;
    String apellido;
    int DNI;
    String telefono;
    String email;

    public  AdministarContactos(){
        this.contactos = new LinkedList <>();
    }
    public void agregarContactos() {


        Scanner n = new Scanner(System.in);
        try {
            System.out.println("ingrese Apellido del contacto");
            apellido = n.nextLine();

            System.out.println("ingrese nombre del contacto");
            nombre = n.nextLine();

            System.out.println("ingrese telefono del contacto");
            telefono = n.nextLine();

            System.out.println("ingrese email del contacto");
            email = n.nextLine();

            System.out.println("ingrese DNI del contacto");
            DNI = n.nextInt();

            Contecto contacto = new Contecto(nombre, apellido, DNI, telefono, email);
            this.contactos.add(contacto);
        }catch (Exception e){
            System.out.println("ERROR EN EL INGRESO DE DATOS");
        }
    }

    public void listarContactos() {
        int cantidadDeContactos = 0;
        for (Contecto lista : contactos) {
            System.out.println(lista);
            cantidadDeContactos++;
        }
        System.out.println("La cantidad de contactos que existen son: "+ cantidadDeContactos);

    }

    public void BuscarPorNombreYApellido() {
        Scanner n = new Scanner(System.in);
        try{
        int CANTIDAIguales=0;
        System.out.print("Buscar contactos con el siguiente NOMBRE: ");
        nombre = n.nextLine();
        System.out.print("Buscar contactos con el siguiente APELLIDO: ");
        apellido = n.nextLine();

            for (Contecto lista : contactos) {
                if (lista.getApellido().equals(apellido)||lista.getNombre().equals(nombre)) {
                    System.out.println(lista.toString());
                    CANTIDAIguales++;
                }
            }
            System.out.println(CANTIDAIguales);
        }catch (Exception e){
            System.out.println("NO EXISTE CONTACTOS QUE CUMPLAN EL CRITERIO");
        }
        }
    public void BuscarPorDNI() {
        Scanner n = new Scanner(System.in);
        try {
        int CANTIDAIguales=0;

        System.out.print("DNI: ");
        int DNIINGESADO = n.nextInt();

        for (Contecto lista : contactos) {
            if (lista.getDNI()==DNIINGESADO) {
                System.out.println(lista.toString());
                CANTIDAIguales++;

            }
        }
        System.out.println(CANTIDAIguales);

    }catch (Exception e){
        System.out.println("NO EXISTE CONTACTOS DON ESTE DNI");
    }
    }
    public void EliminarPorDNI() {
        Scanner n = new Scanner(System.in);
try {
        System.out.print("DNI: ");
        DNI = n.nextInt();

        for (Contecto lista : contactos) {
            if (lista.getDNI()==DNI) {
                contactos.remove(lista);
                break;
            }
        }
    }catch (Exception e){
        System.out.println("NO EXISTE CONTACTOS DON ESTE DNI");
    }
    }
    public void ModificaPorDNI() {
        Scanner n = new Scanner(System.in);

        try {


        System.out.print("DNI: ");
        int DNInuevo = n.nextInt();

        System.out.println("ingrese nuevo Apellido del contacto");
        apellido = n.nextLine();
        n.nextLine();

        System.out.println("ingrese nuevo nombre del contacto");
        nombre = n.nextLine();


        System.out.println("ingrese nuevo telefono del contacto");
        telefono = n.nextLine();

        System.out.println("ingrese nuevo email del contacto");
        email = n.nextLine();

        for (Contecto lista : contactos) {
            if (lista.getDNI()==DNInuevo) {
                System.out.println("Antes de la edicion: "+lista.toString());



                lista.modificarDatos(nombre, apellido,  telefono, email, DNI);

                System.out.println("Despues de la edicion: "+lista.toString());
                break;
            }{

            }
        }
        }catch (Exception e){
            System.out.println("NO EXISTE CONTACTOS DON ESTE DNI");
        }
    }



}
